import sys
import math
from PySide6.QtWidgets import QApplication, QMainWindow, QMessageBox
from Diseño import Ui_MainWindow  # Importar la clase generada desde el archivo .ui

class Matriz(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()  # Asegúrate de que `Ui_MainWindow` es la clase correcta generada desde Qt Designer
        self.ui.setupUi(self)

        self.ui.btnsumar.clicked.connect(self.Suma)
        self.ui.btnRestar.clicked.connect(self.Resta)
        self.ui.btnmultiplicar.clicked.connect(self.Multiplicar)
        self.ui.BtnDerterminante.clicked.connect(self.Inversa)
 
    def Suma(self):
        # Inicializar matrices 3x3 correctamente
        A = [[0] * 3 for _ in range(3)]
        B = [[0] * 3 for _ in range(3)]
        Resultado = [[0] * 3 for _ in range(3)]

        # Llenar las matrices con valores numericos
        try:
            A[0][0] = float(self.ui.SA11.text())
            A[0][1] = float(self.ui.SA12.text())
            A[0][2] = float(self.ui.SA13.text())
            A[1][0] = float(self.ui.SA21.text())
            A[1][1] = float(self.ui.SA22.text())
            A[1][2] = float(self.ui.SA23.text())
            A[2][0] = float(self.ui.SA31.text())
            A[2][1] = float(self.ui.SA32.text())
            A[2][2] = float(self.ui.SA33.text())

            B[0][0] = float(self.ui.SB11.text())
            B[0][1] = float(self.ui.SB12.text())
            B[0][2] = float(self.ui.SB13.text())
            B[1][0] = float(self.ui.SB21.text())
            B[1][1] = float(self.ui.SB22.text())
            B[1][2] = float(self.ui.SB23.text())
            B[2][0] = float(self.ui.SB31.text())
            B[2][1] = float(self.ui.SB32.text())
            B[2][2] = float(self.ui.SB33.text())
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor, ingrese valores numéricos válidos.")

            return
        
        # Sumar matrices
        for i in range(3):
            for j in range(3):
                Resultado[i][j] = A[i][j] + B[i][j]

        # Muestra los resultados en la Matriz Suma
        self.ui.SAB11.setText(str(Resultado[0][0]))
        self.ui.SAB12.setText(str(Resultado[0][1]))
        self.ui.SAB13.setText(str(Resultado[0][2]))
        self.ui.SAB21.setText(str(Resultado[1][0]))
        self.ui.SAB22.setText(str(Resultado[1][1]))
        self.ui.SAB23.setText(str(Resultado[1][2]))
        self.ui.SAB31.setText(str(Resultado[2][0]))
        self.ui.SAB32.setText(str(Resultado[2][1]))
        self.ui.SAB33.setText(str(Resultado[2][2]))



    def Resta (self):
         # Inicializar matrices 3x3 correctamente
        A = [[0] * 3 for _ in range(3)]
        B = [[0] * 3 for _ in range(3)]
        Resultado = [[0] * 3 for _ in range(3)]

        # Llenar las matrices con numeros 
        try:
            A[0][0] = float(self.ui.RA11.text())
            A[0][1] = float(self.ui.RA12.text())
            A[0][2] = float(self.ui.RA13.text())
            A[1][0] = float(self.ui.RA21.text())
            A[1][1] = float(self.ui.RA22.text())
            A[1][2] = float(self.ui.RA23.text())
            A[2][0] = float(self.ui.RA31.text())
            A[2][1] = float(self.ui.RA32.text())
            A[2][2] = float(self.ui.RA33.text())

            B[0][0] = float(self.ui.RB11.text())
            B[0][1] = float(self.ui.RB12.text())
            B[0][2] = float(self.ui.RB13.text())
            B[1][0] = float(self.ui.RB21.text())
            B[1][1] = float(self.ui.RB22.text())
            B[1][2] = float(self.ui.RB23.text())
            B[2][0] = float(self.ui.RB31.text())
            B[2][1] = float(self.ui.RB32.text())
            B[2][2] = float(self.ui.RB33.text())
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor, ingrese valores numéricos válidos.")

            return

        # Resta de Matrices
        for i in range(3):
            for j in range(3):
                Resultado[i][j] = A[i][j] - B[i][j]

        # Muestra los resultados de la resta de matrices
        self.ui.RAB11.setText(str(Resultado[0][0]))
        self.ui.RAB12.setText(str(Resultado[0][1]))
        self.ui.RAB13.setText(str(Resultado[0][2]))
        self.ui.RAB21.setText(str(Resultado[1][0]))
        self.ui.RAB22.setText(str(Resultado[1][1]))
        self.ui.RAB23.setText(str(Resultado[1][2]))
        self.ui.RAB31.setText(str(Resultado[2][0]))
        self.ui.RAB32.setText(str(Resultado[2][1]))
        self.ui.RAB33.setText(str(Resultado[2][2]))

    def Multiplicar (self):
         # Inicializar matrices 3x3 correctamente
        A = [[0] * 3 for _ in range(3)]
        B = [[0] * 3 for _ in range(3)]
        Resultado = [[0] * 3 for _ in range(3)]

        # Llenar las matrices con valores numericos
        try:
            A[0][0] = float(self.ui.MA11.text())
            A[0][1] = float(self.ui.MA12.text())
            A[0][2] = float(self.ui.MA13.text())
            A[1][0] = float(self.ui.MA21.text())
            A[1][1] = float(self.ui.MA22.text())
            A[1][2] = float(self.ui.MA23.text())
            A[2][0] = float(self.ui.MA31.text())
            A[2][1] = float(self.ui.MA32.text())
            A[2][2] = float(self.ui.MA33.text())

            B[0][0] = float(self.ui.MB11.text())
            B[0][1] = float(self.ui.MB12.text())
            B[0][2] = float(self.ui.MB13.text())
            B[1][0] = float(self.ui.MB21.text())
            B[1][1] = float(self.ui.MB22.text())
            B[1][2] = float(self.ui.MB23.text())
            B[2][0] = float(self.ui.MB31.text())
            B[2][1] = float(self.ui.MB32.text())
            B[2][2] = float(self.ui.MB33.text())
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor, ingrese valores numéricos válidos.")

            return

        # Multiplicar matrices
        for i in range(3):
            for j in range(3):
                Resultado[i][j] = A[i][j] * B[i][j]

        # Muestra los resultados de la multiplicacion de matrices
        self.ui.MAB11.setText(str(Resultado[0][0]))
        self.ui.MAB12.setText(str(Resultado[0][1]))
        self.ui.MAB13.setText(str(Resultado[0][2]))
        self.ui.MAB21.setText(str(Resultado[1][0]))
        self.ui.MAB22.setText(str(Resultado[1][1]))
        self.ui.MAB23.setText(str(Resultado[1][2]))
        self.ui.MAB31.setText(str(Resultado[2][0]))
        self.ui.MAB32.setText(str(Resultado[2][1]))
        self.ui.MAB33.setText(str(Resultado[2][2]))


    def obtener_matriz(self):
        """Obtiene la matriz 3x3 desde la interfaz gráfica."""
        try:
            A = [[0] * 3 for _ in range(3)]
            A[0][0] = float(self.ui.MO11.text())
            A[0][1] = float(self.ui.MO12.text())
            A[0][2] = float(self.ui.MO13.text())
            A[1][0] = float(self.ui.MO21.text())
            A[1][1] = float(self.ui.MO22.text())
            A[1][2] = float(self.ui.MO23.text())
            A[2][0] = float(self.ui.MO31.text())
            A[2][1] = float(self.ui.MO32.text())
            A[2][2] = float(self.ui.MO33.text())
            return A
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor, ingrese valores numéricos válidos.")
            return None

    def calcular_determinante(self, A):
        """Calcula el determinante de una matriz 3x3."""
        return (A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1]) -
                A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0]) +
                A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]))

    def calcular_cofactores(self, A):
        """Calcula la matriz de cofactores."""
        cofactores = [[0] * 3 for _ in range(3)]
        for i in range(3):
            for j in range(3):
                # Obtener la submatriz 2x2 eliminando fila i y columna j
                submatriz = [[A[x][y] for y in range(3) if y != j] for x in range(3) if x != i]
                # Determinante de la submatriz 2x2
                det_submatriz = submatriz[0][0] * submatriz[1][1] - submatriz[0][1] * submatriz[1][0]
                # Aplicar signo alternante
                cofactores[i][j] = (-1) ** (i + j) * det_submatriz
                cofactores = [[0] * 3 for _ in range(3)]
        for i in range(3):
            for j in range(3):
                # Crear la submatriz 2x2 eliminando fila i y columna j
                submatriz = []
                for r in range(3):
                    if r != i:
                        fila = []
                        for c in range(3):
                            if c != j:
                                fila.append(A[r][c])
                        submatriz.append(fila)
                
                # Calcular el determinante de la submatriz 2x2
                det_submatriz = submatriz[0][0] * submatriz[1][1] - submatriz[0][1] * submatriz[1][0]
                # Aplicar el signo del cofactor
                cofactores[i][j] = det_submatriz * ((-1) ** (i + j))
        return cofactores

    def transponer_matriz(self, A):
        """Transpone una matriz 3x3."""
        return [[A[j][i] for j in range(3)] for i in range(3)]

    def multiplicar_escalar(self, A, escalar):
        """Multiplica una matriz 3x3 por un escalar."""
        return [[round(A[i][j] * escalar, 4) for j in range(3)] for i in range(3)]
       

    def mostrar_resultado(self, A):
        """Muestra la matriz en la interfaz gráfica."""
        self.ui.MM11.setText(str(A[0][0]))
        self.ui.MM12.setText(str(A[0][1]))
        self.ui.MM13.setText(str(A[0][2]))
        self.ui.MM21.setText(str(A[1][0]))
        self.ui.MM22.setText(str(A[1][1]))
        self.ui.MM23.setText(str(A[1][2]))
        self.ui.MM31.setText(str(A[2][0]))
        self.ui.MM32.setText(str(A[2][1]))
        self.ui.MM33.setText(str(A[2][2]))

    def mostrar_matriz_transpuesta(self, T):
        """Muestra la matriz transpuesta en la interfaz."""
        self.ui.MT11.setText(str(T[0][0]))
        self.ui.MT12.setText(str(T[0][1]))
        self.ui.MT13.setText(str(T[0][2]))
        self.ui.MT21.setText(str(T[1][0]))
        self.ui.MT22.setText(str(T[1][1]))
        self.ui.MT23.setText(str(T[1][2]))
        self.ui.MT31.setText(str(T[2][0]))
        self.ui.MT32.setText(str(T[2][1]))
        self.ui.MT33.setText(str(T[2][2]))

    def mostrar_matriz_adjunta(self, A):
        """Muestra la matriz adjunta (cofactores transpuesta) en la interfaz."""
        self.ui.MR11.setText(str(A[0][0]))
        self.ui.MR12.setText(str(A[0][1]))
        self.ui.MR13.setText(str(A[0][2]))
        self.ui.MR21.setText(str(A[1][0]))
        self.ui.MR22.setText(str(A[1][1]))
        self.ui.MR23.setText(str(A[1][2]))
        self.ui.MR31.setText(str(A[2][0]))
        self.ui.MR32.setText(str(A[2][1]))
        self.ui.MR33.setText(str(A[2][2]))

    def mostrar_matriz_inversa(self, I):
        """Muestra la matriz inversa en la interfaz."""
        self.ui.MI11.setText(str(I[0][0]))
        self.ui.MI12.setText(str(I[0][1]))
        self.ui.MI13.setText(str(I[0][2]))
        self.ui.MI21.setText(str(I[1][0]))
        self.ui.MI22.setText(str(I[1][1]))
        self.ui.MI23.setText(str(I[1][2]))
        self.ui.MI31.setText(str(I[2][0]))
        self.ui.MI32.setText(str(I[2][1]))
        self.ui.MI33.setText(str(I[2][2]))


    def Inversa(self):
        """Calcula la matriz inversa manualmente sin NumPy."""
        A = self.obtener_matriz()
        if A is None:
            return

        # Calcular determinante
        det = self.calcular_determinante(A)
        self.ui.txtdeterminante.setText(str(round(det, 4)))

        # Verificar si la matriz es invertible
        if abs(det) < 1e-6:
            QMessageBox.warning(self, "Error", "La matriz no tiene inversa porque su determinante es 0 o muy pequeño.")
            return
        
        # Calcular y mostrar la matriz transpuesta
        transpuesta = self.transponer_matriz(A)
        self.mostrar_matriz_transpuesta(transpuesta)

        # Calcular matriz de cofactores
        cofactores = self.calcular_cofactores(A)

        # Transponer la matriz de cofactores (adjunta)
        adjunta = self.transponer_matriz(cofactores)
        self.mostrar_matriz_adjunta(adjunta)


        # Multiplicar por 1/det(A) para obtener la inversa
        inversa = self.multiplicar_escalar(adjunta, 1 / det)
        self.mostrar_matriz_inversa(inversa)

        # Mostrar el resultado en la interfaz
        self.mostrar_resultado(inversa)
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myapp = Matriz()
    myapp.show()
    sys.exit(app.exec())
        
